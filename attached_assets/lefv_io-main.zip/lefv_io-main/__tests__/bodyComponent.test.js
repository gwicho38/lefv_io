// __tests__/mainComponent.test.js
import '@testing-library/jest-dom';
import '../public/javascript/components/main-component';

describe('MainComponent', () => {
  let element;

  beforeEach(() => {
    element = document.createElement('main-component');
    document.body.appendChild(element);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  test('renders without crashing', () => {
    expect(element).toBeInTheDocument();
  });

  test('renders child components', () => {
    // Wait for shadow DOM to be populated
    setTimeout(() => {
      expect(element.shadowRoot.querySelector('header-component')).toBeTruthy();
      expect(element.shadowRoot.querySelector('body-component')).toBeTruthy();
      expect(element.shadowRoot.querySelector('footer-component')).toBeTruthy();
    }, 0);
  });

  test('includes CSS stylesheet', () => {
    const style = element.shadowRoot.querySelector('style');
    expect(style).toBeTruthy();
    expect(style.textContent).toContain('main-component.css');
  });
});