// jest.config.js
export default {
    // Test environment setup
    testEnvironment: "jsdom",
    setupFilesAfterEnv: ["<rootDir>/jest.setup.js"],

    // Module resolution
    moduleDirectories: ["node_modules"],
    moduleNameMapper: {
        "\\.(css|less|scss|sass)$": "identity-obj-proxy",
        "^Isotope$": "<rootDir>/node_modules/isotope-layout",
        "^GLightbox$": "<rootDir>/node_modules/glightbox",
        "^Swiper$": "<rootDir>/node_modules/swiper",
        "^AOS$": "<rootDir>/node_modules/aos"
    },

    // Transform setup
    transform: {
        "^.+\\.(js|jsx|ts|tsx)$": ["babel-jest", { "presets": ["@babel/preset-env", "@babel/preset-react"] }]
    },

    // Test file detection
    testMatch: [
        "**/__tests__/**/*.[jt]s?(x)",
        "**/?(*.)+(spec|test).[tj]s?(x)"
    ],

    // Coverage settings
    collectCoverage: true,
    coverageDirectory: "coverage",
    coverageProvider: "v8",

    // Other settings
    clearMocks: true,
    verbose: true
}