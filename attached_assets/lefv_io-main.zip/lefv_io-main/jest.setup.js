// jest.setup.js
import '@testing-library/jest-dom';

// Mock external libraries
jest.mock('Isotope', () => {
    return jest.fn().mockImplementation(() => ({
        arrange: jest.fn(),
        destroy: jest.fn(),
        layout: jest.fn(),
        reloadItems: jest.fn(),
    }));
});

jest.mock('GLightbox', () => {
    return jest.fn().mockImplementation(() => ({
        open: jest.fn(),
        close: jest.fn(),
        destroy: jest.fn(),
    }));
});

jest.mock('Swiper', () => {
    return jest.fn().mockImplementation(() => ({
        init: jest.fn(),
        destroy: jest.fn(),
    }));
});

jest.mock('AOS', () => ({
    init: jest.fn(),
    refresh: jest.fn(),
}));